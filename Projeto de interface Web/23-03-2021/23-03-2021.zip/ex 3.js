var kg = 1
var g = kg * 1000
console.log(`${kg} kg sao iguais a ${g} gramas`)