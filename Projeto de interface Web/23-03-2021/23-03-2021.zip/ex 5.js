var n1 = 10
var n2 = 50
var n3 = 3

var max = Math.max(n1,n2,n3)
console.log(max)
var min = Math.min(n1,n2,n3)
console.log(min)

