nome = "Mario" // Que mario?
idade = 40
sex = "M"
console.log("Nome:",nome)
console.log("Idade:",idade)
console.log("Sexo:",sex)
