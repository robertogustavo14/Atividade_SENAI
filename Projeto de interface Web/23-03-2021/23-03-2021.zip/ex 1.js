var preco = 12
var peso = 0.7 /* peso em Kg*/
var resu = preco * peso
console.log(`O preço do prato é: R$ ${resu} `)