var pri = 25
var seg = 5
if ( seg != 0) {
var resu = pri / seg
console.log(`O resultado da divisão de ${pri} por ${seg} é ${resu}`)
}
else {
    console.log(`O segundo numero é 0 divisão invalida`)
}