var idade = 70

if(idade >= 18 && idade < 50){
console.log("Maior de idade")
} else if (idade < 18 ){
    console.log("Menor de idade")   
}
else {
    console.log("Idoso")
}