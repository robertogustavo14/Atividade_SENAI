var n1 = 201
if (n1 <= 200 && n1 >= 100 ) {
    console.log("Este numero esta entre 100 e 200")
}
else {
    console.log("Este numero não esta entre 100 e 200") 
}