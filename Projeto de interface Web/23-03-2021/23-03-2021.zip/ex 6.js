var n = 11
var resto = n % 2

if (resto === 0){
console.log("Esse numero é par")
}
else{
    console.log("Esse numero é impar")   
}