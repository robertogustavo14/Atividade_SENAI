var x = 10
var y = 15
var tro = 0
console.log("x:",x)
console.log("y:",y)
var tro = y
y = x
x = tro
console.log("x:",x)
console.log("y:",y)
