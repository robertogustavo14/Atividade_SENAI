var raio = 300
const  pi = 3.14 
 var diametro = raio*2
var comprimento = 2*pi*raio
var area = pi*raio**2
console.log(`Diametro: ${diametro}`)
console.log(`comprimento: ${comprimento}`)
console.log(`area: ${area}`)
