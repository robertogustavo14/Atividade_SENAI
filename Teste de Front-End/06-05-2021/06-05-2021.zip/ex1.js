var numero = [1,2,3,4,5,6,7,8]
var quadrado = numero.map(function(num){
    return Math.pow(num,3)
})
console.log(numero)
console.log(quadrado)