var timer = setInterval(ola ,5000)
function ola(){
    console.log("Ola")
    clearInterval(timer)
}

