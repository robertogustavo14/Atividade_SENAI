var quadrados = [25,16,9,4,1]

var raizes = quadrados.map(numero => Math.sqrt(numero))

document.write(raizes)